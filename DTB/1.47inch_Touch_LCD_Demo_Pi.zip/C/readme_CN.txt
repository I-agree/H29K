/*****************************************************************************
* | File      	:   Readme_CN.txt
* | Author      :   Waveshare team
* | Function    :   Help with use
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2024-03-13
* | Info        :   在这里提供一个中文版本的使用文档，以便你的快速使用
******************************************************************************/
这个文件是帮助您使用本例程。

1.基本信息：
本例程使用单独LCD模块进行了验证，你可以在工程的Examples\中查看对应的测试例程;
本例程均在Raspberry Pi 4B上进行了验证;

2.管脚连接：
管脚连接你可以在\lib\Config目录下查看DEV_Config.h中查看，这里也再重述一次：
LCD         ->    RPI(BCM)
VCC         ->    3.3V
GND        ->    GND
LCD_DIN  ->    10(SPI0_MOSI)
LCD_CLK  ->    11(SPI0_SCK)
LCD_CS    ->    8(CE0)
LCD_DC    ->    25
LCD_RST   ->    27
LCD_BL     ->    18

Touch  	=>	  RPI(BCM)
TP_SDA  ->    SDA
TP_SCL  ->    SCL
TP_RST  ->    17
TP_IRQ  ->    4

3.安装库：
git clone https://github.com/WiringPi/WiringPi
cd WiringPi
./build
gpio -v
# 运行gpio -v会出现版本，如果没有出现说明安装出错

4.基本使用：

你需要执行：make,编译程序，会生成可执行文件：main
运行：sudo ./main 

如果修改了程序，需要执行：make clean,然后重新make。

5.目录结构（选读）：
如果你经常使用我们的产品，对我们的程序目录结构会十分熟悉，关于具体的函数的我们有一份
函数的API手册，你可以在我们的WIKI上下载或像售后客服索取，这里简单介绍一次：
\lib\Config\:此目录为硬件接口层文件，在DEV_Config.c(.h)可以看到很多定义，包括：
    数据类型;
    GPIO;
    读写GPIO;
    延时：注意：此延时函数并未使用示波器测量具体数值,因此会不准;
    模块初始化与退出的处理：
        void DEV_Module_Init(void);
        void DEV_Module_Exit(void);
           
\lib\GUI\:此目录为一些基本的图像处理函数，在GUI_Paint.c(.h)中：
    常用图像处理：创建图形、翻转图形、镜像图形、设置像素点、清屏等;
    常用画图处理：画点、线、框、圆、中文字符、英文字符、数字等;
    常用时间显示：提供一个常用的显示时间函数;
    常用显示图片：提供一个显示位图的函数;
    
\lib\Fonts\:为一些常用的字体：
    Ascii:
        font8: 5*8 
        font12: 7*12
        font16: 11*16 
        font20: 14*20 
        font24: 17*24
    中文：
        font12CN: 16*21 
        font24CN: 32*41
        
\lib\LCD\:此目录下为液晶屏驱动函数跟触摸驱动函数;

Examples\:此目录下为液晶屏的测试程序，你可在其中看到具体的使用现象;

