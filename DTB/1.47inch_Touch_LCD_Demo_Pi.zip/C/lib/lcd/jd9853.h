#ifndef __JD9853_H__
#define __JD9853_H__

#include "DEV_Config.h"
#include <stdint.h>

#include <stdlib.h>		//itoa()
#include <stdio.h>


#define JD9853_WIDTH        320
#define JD9853_HEIGHT       480

void jd9853_init(void);
void jd9853_draw_rectangle(uint16_t x_start, uint16_t y_start, uint16_t x_end, uint16_t y_end, uint16_t color);
void jd9853_clear(uint16_t color);

#endif  // __JD9853_H__

