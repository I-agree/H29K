#ifndef __AXS5106L_H__
#define __AXS5106L_H__

#include "DEV_Config.h"
#include <stdint.h>

#include <stdlib.h>		//itoa()
#include <stdio.h>

#include "Debug.h"

#include "stdbool.h"


#define AXS5106L_ADDR 0x63
#define AXS5106L_ID_REG 0x08


typedef struct{
    uint16_t x;
    uint16_t y;
}touch_coords_t;

typedef struct{
  touch_coords_t coords[2];
  uint16_t touch_num;
}touch_data_t;

void axs5106l_init(void);

bool get_touch_data(touch_data_t *touch_data);


#endif  // __AXS5106L_H__
