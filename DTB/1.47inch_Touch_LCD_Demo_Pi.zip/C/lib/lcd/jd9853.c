#include "jd9853.h"

static void jd9853_write_bytes(uint8_t *data, uint32_t lenght)
{
    LCD_DC_1;
    DEV_SPI_Write_nByte(data, lenght);
}

static void jd9853_write_byte(uint8_t data)
{
    LCD_DC_1;
    // LCD_2IN8_CS_0;
    DEV_SPI_WriteByte(data);
    // LCD_2IN8_CS_1;
}

static void jd9853_write_cmd(uint8_t cmd)
{
    LCD_DC_0;
    // LCD_2IN8_CS_0;
    DEV_SPI_WriteByte(cmd);
    // LCD_2IN8_CS_1;
}

static void jd9853_rst(void)
{
    LCD_RST_1;
    DEV_Delay_ms(100);
    LCD_RST_0;
    DEV_Delay_ms(100);
    LCD_RST_1;
    DEV_Delay_ms(100);
}

void jd9853_init(void)
{
    // JD9853_BOE1.47_WV015GES-NB80_172x320_230831_johnson.c

    // SET_PASSWD
    jd9853_rst();
    DEV_Delay_ms(120);
    jd9853_write_cmd(0x11);

    DEV_Delay_ms(120);

    jd9853_write_cmd(0xDF);
    jd9853_write_byte(0x98);
    jd9853_write_byte(0x53);

    jd9853_write_cmd(0xDF);
    jd9853_write_byte(0x98);
    jd9853_write_byte(0x53);

    jd9853_write_cmd(0xB2);
    jd9853_write_byte(0x23);

    jd9853_write_cmd(0x36); // memory access control

    jd9853_write_byte(0x00); // MY MX MV ML MH=0,BGR=1

    jd9853_write_cmd(0xB7);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x47);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x6F);

    jd9853_write_cmd(0xBB);
    jd9853_write_byte(0x1C);
    jd9853_write_byte(0x1A);
    jd9853_write_byte(0x55);
    jd9853_write_byte(0x73);
    jd9853_write_byte(0x63);
    jd9853_write_byte(0xF0);

    jd9853_write_cmd(0xC0);
    jd9853_write_byte(0x44);
    jd9853_write_byte(0xA4);

    jd9853_write_cmd(0xC1);
    jd9853_write_byte(0x16);

    jd9853_write_cmd(0xC3);
    jd9853_write_byte(0x7D);
    jd9853_write_byte(0x07);
    jd9853_write_byte(0x14);
    jd9853_write_byte(0x06);
    jd9853_write_byte(0xCF);
    jd9853_write_byte(0x71);
    jd9853_write_byte(0x72);
    jd9853_write_byte(0x77);

    jd9853_write_cmd(0xC4);
    jd9853_write_byte(0x00); // 00=60Hz 06=57Hz 08=51Hz
    jd9853_write_byte(0x00);
    jd9853_write_byte(0xA0); // LN=320  Line
    jd9853_write_byte(0x79);
    jd9853_write_byte(0x0B);
    jd9853_write_byte(0x0A);
    jd9853_write_byte(0x16);
    jd9853_write_byte(0x79);
    jd9853_write_byte(0x0B);
    jd9853_write_byte(0x0A);
    jd9853_write_byte(0x16);
    jd9853_write_byte(0x82);

    // SET_R_GAMMA 20230718 VOP5.25 G2.2

    jd9853_write_cmd(0xC8);
    jd9853_write_byte(0x3F);
    jd9853_write_byte(0x32);
    jd9853_write_byte(0x29);
    jd9853_write_byte(0x29);
    jd9853_write_byte(0x27);
    jd9853_write_byte(0x2B);
    jd9853_write_byte(0x27);
    jd9853_write_byte(0x28);
    jd9853_write_byte(0x28);
    jd9853_write_byte(0x26);
    jd9853_write_byte(0x25);
    jd9853_write_byte(0x17);
    jd9853_write_byte(0x12);
    jd9853_write_byte(0x0D);
    jd9853_write_byte(0x04);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x3F);
    jd9853_write_byte(0x32);
    jd9853_write_byte(0x29);
    jd9853_write_byte(0x29);
    jd9853_write_byte(0x27);
    jd9853_write_byte(0x2B);
    jd9853_write_byte(0x27);
    jd9853_write_byte(0x28);
    jd9853_write_byte(0x28);
    jd9853_write_byte(0x26);
    jd9853_write_byte(0x25);
    jd9853_write_byte(0x17);
    jd9853_write_byte(0x12);
    jd9853_write_byte(0x0D);
    jd9853_write_byte(0x04);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0xD0);
    jd9853_write_byte(0x04);
    jd9853_write_byte(0x06);
    jd9853_write_byte(0x6B);
    jd9853_write_byte(0x0F);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0xD7);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x30);

    jd9853_write_cmd(0xE6);
    jd9853_write_byte(0x14);

    jd9853_write_cmd(0xDE);
    jd9853_write_byte(0x01);

    jd9853_write_cmd(0xB7);
    jd9853_write_byte(0x03);
    jd9853_write_byte(0x13);
    jd9853_write_byte(0xEF);
    jd9853_write_byte(0x35);
    jd9853_write_byte(0x35);

    jd9853_write_cmd(0xC1);
    jd9853_write_byte(0x14);
    jd9853_write_byte(0x15);
    jd9853_write_byte(0xC0);

    jd9853_write_cmd(0xC2);
    jd9853_write_byte(0x06);
    jd9853_write_byte(0x3A);

    jd9853_write_cmd(0xC4);
    jd9853_write_byte(0x72);
    jd9853_write_byte(0x12);

    jd9853_write_cmd(0xBE);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0xDE);
    jd9853_write_byte(0x02);

    jd9853_write_cmd(0xE5);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x02);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0xE5);
    jd9853_write_byte(0x01);
    jd9853_write_byte(0x02);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0xDE);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0x35);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0x3A);
    jd9853_write_byte(0x05); // 06=RGB666；05=RGB565

    jd9853_write_cmd(0x2A);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x22); // Start_X=34
    jd9853_write_byte(0x00);
    jd9853_write_byte(0xCD); // End_X=205

    jd9853_write_cmd(0x2B);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x00); // Start_Y=0
    jd9853_write_byte(0x01);
    jd9853_write_byte(0x3F); // End_Y=319

    jd9853_write_cmd(0xDE);
    jd9853_write_byte(0x02);

    jd9853_write_cmd(0xE5);
    jd9853_write_byte(0x00);
    jd9853_write_byte(0x02);
    jd9853_write_byte(0x00);

    jd9853_write_cmd(0xDE);
    jd9853_write_byte(0x00);

    // jd9853_write_cmd(0xC2);
    // jd9853_write_byte(0x08);

    jd9853_write_cmd(0x29);
    jd9853_write_cmd(0x21);

    DEV_Delay_ms(10);
}

void jd9853_set_windows(uint16_t x_start, uint16_t y_start, uint16_t x_end, uint16_t y_end)
{
    uint8_t buffer[4];
    x_start = x_start + 34;
    x_end = x_end + 34;
    buffer[0] = x_start >> 8;
    buffer[1] = (uint8_t)(x_start & 0x00ff);
    buffer[2] = x_end >> 8;
    buffer[3] = (uint8_t)(x_end & 0x00ff);
    jd9853_write_cmd(0x2a);
    jd9853_write_bytes(buffer, 4);

    buffer[0] = y_start >> 8;
    buffer[1] = (uint8_t)(y_start & 0x00ff);
    buffer[2] = y_end >> 8;
    buffer[3] = (uint8_t)(y_end & 0x00ff);
    jd9853_write_cmd(0x2b);
    jd9853_write_bytes(buffer, 4);
    jd9853_write_cmd(0x2c);
}

void jd9853_draw_rectangle(uint16_t x_start, uint16_t y_start, uint16_t x_end, uint16_t y_end, uint16_t color)
{
    uint8_t color_h = color >> 8;
    uint8_t color_l = (uint8_t)(color && 0x00ff);
    uint16_t i = 0;
    uint16_t color_lenght = (1 + x_end - x_start) * (1 + y_end - y_start);
    jd9853_set_windows(x_start, y_start, x_end, y_end);
    for (i = 0; i < color_lenght; i++)
    {
        jd9853_write_byte(color_h);
        jd9853_write_byte(color_l);
    }
}

void jd9853_flush(uint16_t x_start, uint16_t y_start, uint16_t x_end, uint16_t y_end, uint16_t *color)
{
}

uint16_t swap_uint16(uint16_t val)
{
    return (val << 8) | (val >> 8);
}

void jd9853_clear(uint16_t color)
{

    uint16_t buf[JD9853_WIDTH];
    uint16_t i;
    color = swap_uint16(color);
    for (i = 0; i < JD9853_WIDTH; i++)
        buf[i] = color;

    jd9853_set_windows(0, 0, JD9853_WIDTH - 1, JD9853_HEIGHT - 1);

    for (i = 0; i < JD9853_HEIGHT; i++)
        jd9853_write_bytes((uint8_t *)buf, JD9853_WIDTH * 2);
}
