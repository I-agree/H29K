#include "axs5106l.h"

static bool axs5106l_read_flag = true;
static bool axs5106l_int_enable = false;

static void axs5106l_read(uint8_t reg_addr, uint8_t *data, uint32_t length)
{
  I2C_Read_nByte(reg_addr, data, length);
}

bool get_touch_data(touch_data_t *touch_data)
{
  uint8_t data[14];
  uint8_t points;

  if (axs5106l_int_enable)
  {
    if (false == axs5106l_read_flag)
    {
      // Serial.println("axs5106l_read_flag is false");
      return false;
    }
    else
    {
      axs5106l_read_flag = false;
    }
  }
  axs5106l_read(0x01, data, 14);
  points = data[1];
  points = points & 0x0F;

  if (points == 0)
  {
    return false;
  }

  /* Number of touched points */
  points = (points > 2 ? 2 : points);

  /* Number of touched points */
  touch_data->touch_num = points;

  /* Fill all coordinates */
  for (int i = 0; i < points; i++)
  {
    touch_data->coords[i].y = (((uint16_t)(data[4 + i * 6] & 0x0f)) << 8);
    touch_data->coords[i].y |= data[5 + i * 6];
    touch_data->coords[i].x = ((uint16_t)(data[2 + i * 6] & 0x0f)) << 8;
    touch_data->coords[i].x |= data[3 + i * 6];
  }
  return true;
}

// 中断服务函数
void ft6336_touch_int_cb(void)
{
  axs5106l_read_flag = true;
}

void axs5106l_touch_rst(void)
{
  TP_RST_0;
  DEV_Delay_ms(100);
  TP_RST_1;
  DEV_Delay_ms(200);
}

void axs5106l_init(void)
{
  uint8_t id[4];
  axs5106l_touch_rst();

  axs5106l_read(AXS5106L_ID_REG, id, 3);
  id[3] = '\0';
  DEBUG("axs5106l id: %s\r\n", (char *)id);

  wiringPiISR(TP_INT, INT_EDGE_FALLING, &ft6336_touch_int_cb);
  axs5106l_int_enable = true;
}
