#include "test.h"
#include <math.h>
#include <stdlib.h> //exit()
#include <stdio.h>

#include "DEV_Config.h"
#include "jd9853.h"
#include "axs5106l.h"

uint16_t color_arr[4] = {0xF800, 0x07E0, 0x001F, 0xFFFF};

int main()
{
    touch_data_t touch_data;
    /* Module Init */
    if (DEV_ModuleInit() != 0)
    {
        DEV_ModuleExit();
        exit(0);
    }

    jd9853_init();
    axs5106l_init();

    jd9853_clear(color_arr[0]);
    DEV_Delay_ms(1000);
    jd9853_clear(color_arr[1]);
    DEV_Delay_ms(1000);
    jd9853_clear(color_arr[2]);
    DEV_Delay_ms(1000);
    jd9853_clear(color_arr[3]);
    while (1)
    {
        if (get_touch_data(&touch_data))
        {
            for (int i = 0; i < touch_data.touch_num; i++)
            {
                touch_data.coords[i].x = 171 - touch_data.coords[i].x;
                printf("x: %d, y: %d \r\n", touch_data.coords[i].x, touch_data.coords[i].y);
                jd9853_draw_rectangle(touch_data.coords[i].x, touch_data.coords[i].y, touch_data.coords[i].x + 4, touch_data.coords[i].y + 4, color_arr[i]);
            }
        }
        DEV_Delay_ms(10);
    }

    return 0;
}
